#R TUTORIAL: MAPPING SAN FRANCISCO'S RESIDENTIAL REAL ESTATE MARKET

by [Simon Kassel](http://simonkassel.com/blog/2017/2/21/mapping-and-visualizing-san-franciscos-residential-real-estate-market-with-r) and [Ken Steif](http://urbanspatialanalysis.com/dataviz-tutorial-mapping-san-francisco-home-prices-using-r/)

Exploratory visualizations of SF home sale records from San Francisco (2009-2015)

Data: San Francisco Office of the Assessor-Recorder
